# India–USA Cultural Performing Arts Initiative
## Research Plan & Website Build Package

**Project:** Bi-coastal pilot festival of Indian performing arts (music, dance, theater) in Seattle + California, Year 1 pilot feeding into a larger Year 2 festival.

**Timeline:** 6 months to inaugural pilot.

**This folder** is structured for Claude Code to read and turn into a research-findings website.

---

## 📁 Folder Structure

```
research-plan/
├── README.md                    ← You are here. Build instructions.
├── content/                     ← Human-readable Markdown content
│   ├── 01-executive-summary.md
│   ├── 02-city-decision.md      ← LA vs SF Bay Area analysis
│   ├── 03-sponsor-structures.md ← 3 legal/partner options compared
│   ├── 04-consulate-programs.md ← All India-US consulate programs
│   ├── 05-precedents.md         ← What's been done before
│   ├── 06-stakeholder-map.md
│   ├── 07-pilot-festival-concept.md
│   ├── 08-funding-stack.md
│   ├── 09-p3-visa-playbook.md
│   ├── 10-timeline.md
│   ├── 11-open-questions.md
│   ├── 12-outreach-templates.md
│   └── 13-seattle-local-advantages.md
├── data/                        ← Machine-readable JSON for the website
│   ├── consulates.json          ← 4 consulates + Embassy DC
│   ├── programs.json            ← All programs catalog (structured)
│   ├── stakeholders.json        ← Contact map
│   ├── precedents.json          ← Prior events
│   ├── timeline.json            ← Week-by-week milestones
│   ├── funding-sources.json     ← Grant opportunities
│   └── sponsor-options.json     ← 3 structures comparison
└── assets/                      ← (empty, reserved for logos/images)
```

---

## 🛠️ BUILD INSTRUCTIONS FOR CLAUDE CODE

When reading this folder to generate a website, Claude Code should:

### 1. Recommended Stack
- **Framework:** Next.js 14 (App Router) with TypeScript, OR simple Vite + React if preferred
- **Styling:** Tailwind CSS
- **Content:** Parse Markdown files in `/content` using `remark` or `@next/mdx`
- **Data:** Import JSON files from `/data` directly
- **Deployment:** Vercel or Netlify

### 2. Recommended Site Structure (pages)

| Page | Route | Source |
|---|---|---|
| Home / Overview | `/` | `01-executive-summary.md` + dashboard cards pulling from `data/*.json` |
| City Decision | `/city-analysis` | `02-city-decision.md` |
| Partner Structures | `/sponsor-structures` | `03-sponsor-structures.md` + `data/sponsor-options.json` |
| Consulate Programs Catalog | `/programs` | `04-consulate-programs.md` + `data/programs.json` (filterable by consulate + program type) |
| Precedent Research | `/precedents` | `05-precedents.md` + `data/precedents.json` (timeline view) |
| Stakeholders | `/stakeholders` | `06-stakeholder-map.md` + `data/stakeholders.json` (searchable contact directory) |
| Festival Concept | `/concept` | `07-pilot-festival-concept.md` |
| Funding | `/funding` | `08-funding-stack.md` + `data/funding-sources.json` |
| Visa Playbook | `/visa-playbook` | `09-p3-visa-playbook.md` |
| Timeline | `/timeline` | `10-timeline.md` + `data/timeline.json` (Gantt-style view) |
| Open Questions | `/open-questions` | `11-open-questions.md` |
| Outreach Templates | `/outreach` | `12-outreach-templates.md` |
| Seattle Local Playbook | `/seattle-playbook` | `13-seattle-local-advantages.md` |

### 3. Recommended Components

- **`<ProgramCard />`** — displays one program from `programs.json` with: name, consulate, eligibility, how-to-apply, timeline, contact. Filterable.
- **`<ConsulateCard />`** — displays one consulate with: jurisdiction, CG name, contact, current cultural focus.
- **`<TimelineItem />`** — one milestone with week, action, owner, status.
- **`<StakeholderCard />`** — person/org with tier, role, why-matter.
- **`<FundingSourceCard />`** — funder, what-covers, realistic-in-timeline, next-action.
- **`<DecisionMatrix />`** — reusable 2-option comparison component (used for LA vs SF, sponsor structures).

### 4. Design Direction

- **Tone:** Professional research dossier, not a marketing site. Think "McKinsey deck meets arts nonprofit."
- **Color palette:** India saffron (`#FF9933`) + India green (`#138808`) + US navy (`#1F3A5F`) as accents. White/cream background.
- **Typography:** Serif for headings (suggest: Playfair Display or similar), clean sans for body (Inter).
- **Layout:** Two-column where possible — content on left, structured data on right.

### 5. Must-Have Interactive Features

- Program catalog with **filters** (by consulate, by program type, by deadline proximity)
- Stakeholder directory with **search**
- Timeline with **status toggles** (Not started / In progress / Done)
- "Contact this person" pre-filled mailto links wherever an email exists
- Printable/PDF-export version of the Executive Summary

### 6. Do NOT Add

- User authentication
- Database / CMS (all content is in this folder)
- Complex animations
- Multiple language support (English only for now)

---

## 📌 Single-Source-of-Truth Policy

If any content needs updating, update the corresponding file in `/content` or `/data`. The website is a view on top of these files — nothing else.

---

*Prepared as of April 2026. Refresh programs.json and deadlines quarterly.*
